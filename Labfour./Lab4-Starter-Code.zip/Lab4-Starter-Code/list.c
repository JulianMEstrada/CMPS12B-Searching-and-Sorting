#include <stdlib.h>
#include "list.h"
#include <stdio.h>

Node* make_node(void* data, void* next){
	/* 
	* TODO 2
	*/ 
	
	return NULL; // replace this
	/* 
	* TODO 2
	*/ 
}

List* make_list(){
	/* 
	* TODO 2
	*/ 
	
	return NULL; // replace this
	/* 
	* TODO 2
	*/ 
}

void free_node(Node* node){
	
	/* 
	* TODO 2
	*/ 
	
	/* 
	* TODO 2
	*/ 
}

void free_list(List* list) {
	
	/* 
	* TODO 2
	*/ 
	
	/* 
	* TODO 2
	*/ 
}

void add(List* list, int index, void* data) {
	
	/* 
	* TODO 2
	*/ 
	
	/* 
	* TODO 2
	*/ 
}

void* get(List* list, int index){
	/* 
	* TODO 2
	*/ 
	
	return NULL; // replace this
	/* 
	* TODO 2
	*/ 
}

void set(List* list, int index, void* data) {
	
	/* 
	* TODO 2
	*/ 
	
	/* 
	* TODO 2
	*/ 
}
